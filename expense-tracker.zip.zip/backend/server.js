const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");

const app = express();

app.use(cors());
app.use(express.json());

mongoose.connect("mongodb://SMPRANJAL:SNOWMANILOVEFOREVER@ac-tmahyue-shard-00-00.8ck5l30.mongodb.net:27017,ac-tmahyue-shard-00-01.8ck5l30.mongodb.net:27017,ac-tmahyue-shard-00-02.8ck5l30.mongodb.net:27017/?ssl=true&replicaSet=atlas-sv0vqs-shard-0&authSource=admin&appName=SNOW")
  .then(() => console.log("DB Connected"))
  .catch(err => console.log(err));
  

app.use("/users", require("./routes/userRoutes"));
app.use("/expenses", require("./routes/expenseRoutes"));

app.listen(5000, () => console.log("Server running on port 5000"));